import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Check, MessageCircle, ArrowLeft } from 'lucide-react';
import type { CartItem, CustomerData, PaymentMethod } from '@/types';

gsap.registerPlugin(ScrollTrigger);

interface OrderSummarySectionProps {
  id?: string;
  items: CartItem[];
  customer: CustomerData;
  paymentMethod: PaymentMethod;
  onConfirm: () => void;
  onBack: () => void;
}

const paymentMethodLabels: Record<PaymentMethod, string> = {
  cartao: 'Cartão',
  multibanco: 'Multibanco',
  mbway: 'MB WAY',
  transferencia: 'Transferência',
};

export function OrderSummarySection({ 
  id,
  items, 
  customer, 
  paymentMethod, 
  onConfirm, 
  onBack 
}: OrderSummarySectionProps) {
  const sectionRef = useRef<HTMLElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const bgRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const card = cardRef.current;
    const bg = bgRef.current;

    if (!section || !card || !bg) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=120%',
          pin: true,
          scrub: 0.6,
        }
      });

      // Entrance (0-30%)
      scrollTl.fromTo(bg,
        { scale: 1.08, opacity: 0.7 },
        { scale: 1, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(card,
        { y: '60vh', scale: 0.92, opacity: 0 },
        { y: 0, scale: 1, opacity: 1, ease: 'power2.out' },
        0
      );

      // Line items stagger
      const lineItems = card.querySelectorAll('.line-item');
      scrollTl.fromTo(lineItems,
        { y: 20, opacity: 0 },
        { y: 0, opacity: 1, stagger: 0.02, ease: 'power2.out' },
        0.1
      );

      // Exit (70-100%)
      scrollTl.fromTo(card,
        { y: 0, opacity: 1 },
        { y: '-40vh', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(bg,
        { scale: 1, opacity: 1 },
        { scale: 1.05, opacity: 0.6, ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const subtotal = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  return (
    <section 
      ref={sectionRef}
      id={id}
      className="relative w-full h-screen flex items-center justify-center"
      style={{ zIndex: 40 }}
    >
      {/* Background */}
      <div 
        ref={bgRef}
        className="absolute inset-0"
      >
        <img 
          src="/images/backgrounds/hero_botanical.jpg" 
          alt="Background"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/30" />
      </div>

      {/* Summary Card */}
      <div 
        ref={cardRef}
        className="relative w-full max-w-lg mx-4 bg-white rounded-[28px] shadow-2xl p-6 lg:p-8"
      >
        {/* Success Icon */}
        <div className="flex justify-center mb-6">
          <div className="w-16 h-16 bg-gold-100 rounded-full flex items-center justify-center">
            <Check className="w-8 h-8 text-gold-600" />
          </div>
        </div>

        <h2 className="text-2xl lg:text-3xl font-heading font-bold text-sage-900 text-center mb-2">
          Resumo da encomenda
        </h2>
        <p className="text-sage-600 text-center mb-6">
          Revisa os detalhes antes de confirmar
        </p>

        {/* Items */}
        <div className="space-y-3 mb-6 max-h-48 overflow-y-auto bg-sage-50 rounded-xl p-4">
          {items.map((item) => (
            <div key={item.product.id} className="line-item flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="text-sm text-sage-500">x{item.quantity}</span>
                <span className="text-sm text-sage-900">{item.product.name}</span>
              </div>
              <span className="text-sm font-medium text-sage-900">
                €{(item.product.price * item.quantity).toFixed(2)}
              </span>
            </div>
          ))}
        </div>

        {/* Customer Info */}
        <div className="line-item space-y-2 mb-6 text-sm">
          <div className="flex justify-between">
            <span className="text-sage-500">Cliente</span>
            <span className="text-sage-900">{customer.firstName} {customer.lastName}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-sage-500">Telefone</span>
            <span className="text-sage-900">{customer.phone}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-sage-500">Pagamento</span>
            <span className="text-sage-900">{paymentMethodLabels[paymentMethod]}</span>
          </div>
        </div>

        {/* Total */}
        <div className="line-item flex items-center justify-between pt-4 border-t border-sage-100 mb-6">
          <span className="font-heading font-bold text-sage-900">Total</span>
          <span className="font-heading font-bold text-2xl text-gold-600">
            €{subtotal.toFixed(2)}
          </span>
        </div>

        {/* Actions */}
        <div className="space-y-3">
          <button
            onClick={onConfirm}
            className="w-full btn-primary flex items-center justify-center gap-2"
          >
            <MessageCircle className="w-5 h-5" />
            Enviar por WhatsApp
          </button>
          <button
            onClick={onBack}
            className="w-full flex items-center justify-center gap-2 py-3 text-sage-600 hover:text-sage-900 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Voltar ao checkout
          </button>
        </div>

        <p className="text-xs text-sage-500 text-center mt-4">
          A revendedora confirmará o valor total com portes via WhatsApp.
        </p>
      </div>
    </section>
  );
}
